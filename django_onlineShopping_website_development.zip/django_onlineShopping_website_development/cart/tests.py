from django.test import TestCase

# Create your tests here.
# to test models , views, urls, forms.